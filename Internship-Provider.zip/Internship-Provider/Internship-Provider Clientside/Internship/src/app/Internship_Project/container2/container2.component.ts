import { Component } from '@angular/core';
import { NavigationComponent2 } from '../Navigation2/Navigation2.component';

@Component({
  selector: 'app-container2',
  templateUrl: './container2.component.html',
  styleUrls: ['./container2.component.css']
})
export class ContainerComponent2 {
  
 

}
