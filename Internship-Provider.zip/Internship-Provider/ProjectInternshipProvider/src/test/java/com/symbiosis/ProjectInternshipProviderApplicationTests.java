package com.symbiosis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectInternshipProviderApplicationTests {

	@Test
	void contextLoads() {
	}

}
