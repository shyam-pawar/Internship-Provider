import { Component } from '@angular/core';

@Component({
  selector: 'app-findinternship',
  templateUrl: './findinternship.component.html',
  styleUrls: ['./findinternship.component.css']
})
export class FindinternshipComponent {

}
