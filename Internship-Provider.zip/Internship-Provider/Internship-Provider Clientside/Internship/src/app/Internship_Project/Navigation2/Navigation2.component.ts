import { Component } from '@angular/core';

@Component({
  selector: 'second-navigation',
  templateUrl: './navigation2.component.html',
  styleUrls: ['./navigation2.component.css']
})
export class NavigationComponent2 {

}
