export class Interns{
      id!: number;
	  firstName!:string;
	  lastName!:string;
	  email!:string;
	  phoneNumber!:string;
	  qualification!:string;
	  userName!:string;
	  password!:string;
	  marital_status!:string;
	
}